[Forms MVC Widget](https://stash.backbase.com/projects/FORMS/repos/widget-forms-mvc/browse)
===========================

This widget uses the [Forms Angular UI](https://stash.backbase.com/projects/FORMS/repos/forms-angular-ui/browse)
to render Backbase forms inline in a widget.
 
It makes use of [Forms Proxy Service](https://stash.backbase.com/projects/FORMS/repos/forms-proxy-service/browse) when requesting the forms-runtime.

 In order to build and use the widget, follow the steps below:
 
 - Make sure to have a running portal, based on launchpad-achetype-CXP5.6-2.3.0 or higher version.
 - Download the latest stable widget from [repo](https://repo.backbase.com/expert-forms-releases/com/backbase/expert/forms/widgets/widget-forms-mvc) 
 or [artifacts](https://artifacts.backbase.com/expert-forms-releases/com/backbase/expert/forms/widgets/widget-forms-mvc).
 - Extract the zip to folder `widget-forms-mvc` in `statics/collection/components`.
 - Add dependency "widget-forms-mvc":"./components/widget-forms-mvc" containing the correct path under the dependencies element statics/collection/bower.json. 
 
 ```
   "dependencies": {
     "widget-forms-mvc": "./components/widget-forms-mvc"
   }
 ```
 
 - `cd statics/collection`
 - Import the dashboard if you have not done so yet.
    - Run `bb import --dashboard` OR 
    - Run `mvn clean install -Psetup-collections`
 - Run `bower install`.
 - Run `bb import-collection -a`. The -a option will auto-generate model.xml for all features.
 - Make sure your form flow has a shortcut, defined in `forms-home/src/main/templates/aquima.properties`.
 Below is an example. `${env.model.location}` needs to be defined in the filters, and should be replaced by either `export` or `studio-RepoName`
 
 ```
 # kinderbijslag
 #project=export-Kinderbijslag&flow=Start&version=0.0-Trunk&languageCode=nl-NL&ui=mvc&theme=bootstrap3
 shortcut.kinderbijslag.flow=Start
 shortcut.kinderbijslag.languageCode=nl-NL
 #shortcut.kinderbijslag.project=${env.model.location}-Kinderbijslag
 shortcut.kinderbijslag.project=export-Kinderbijslag
 shortcut.kinderbijslag.theme=bootstrap3
 shortcut.kinderbijslag.ui=mvc
 shortcut.kinderbijslag.version=0.0-Trunk
 ```
 
 - Build `forms-home` module with `mvn clean install -Psetup-forms-frontend`
 - In the runtime dashboard, click **Reload Configuration**
 - You can test if the shortcut is correctly configured by going to Settings --> General --> Shortcuts (in Forms Dashboard), and clicking Start on the shortcut you created. 
 - Add the Forms Widget to your portal catalog.
 - Instantiate the Forms Widget on a page in your portal.
 - The Forms Widget should now show a message indicating you need to configure the shortcut.
 - Open widget settings in CXP manager.
 - Select your previously created shortcut from the dropdown.
 - Click Save.
 - The form should now be rendered.