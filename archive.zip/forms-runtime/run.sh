#!/bin/sh
mvn jetty:run