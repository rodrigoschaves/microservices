package com.backbase.expert.forms.extensions.services;

import com.aquima.interactions.foundation.DataType;
import com.aquima.interactions.foundation.IPrimitiveValue;
import com.aquima.interactions.foundation.types.EntityValue;
import com.aquima.interactions.portal.IService;
import com.aquima.interactions.portal.IServiceContext;
import com.aquima.interactions.profile.IEntityInstance;
import com.aquima.interactions.rule.InferenceContext;
import com.aquima.interactions.test.templates.ApplicationTemplate;
import com.aquima.interactions.test.templates.context.ServiceContextTemplate;
import com.aquima.interactions.test.templates.model.EntityTemplate;
import com.backbase.expert.forms.context.AquimaContextLoader;
import com.backbase.expert.forms.extensions.utils.FormsUtils;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

/**
 * Test class for GetValueFromArrayService.
 * 
 * @author wiene
 *
 */
public class GetValueFromArrayServiceTest extends AquimaContextLoader {

    private static final String projectZipPath = "/exports/Plugins.project.zip";
    private static final String profileXmlPath = "/exports/Start_Plugins.get-value-from-array-profile.xml";

    private IService service;
    private IServiceContext context;

    @Before
    public void setup() throws Exception {
        String serviceCallName = "WhateverServiceName";
        String serviceTypeName = "BB_GetValueFromArray";
        Map<String, String> expressionParameters = createExpressionParameterMap();
        Map<String, String> valueParameters = null;

        context = loadFullContext(projectZipPath, profileXmlPath, serviceCallName, serviceTypeName,
                valueParameters, expressionParameters);
        service = new GetValueFromArrayService();
    }
    
    private Map<String,String> createExpressionParameterMap() {
        Map<String, String> params = new HashMap<String, String>();
        params.put("multi-value", "Plugins.FruitTree");
        params.put("position", "Plugins.Position");
        params.put("result", "Plugins.ReturnedValueFromFruits");
        return params;
    }
    
    @Test
    public void testGetValueFromArrayWithProfile() throws Exception {
        InferenceContext profile = context.getProfile();        
        assertNotNull(profile);
        
        IEntityInstance fruitEntityInstance = profile.getActiveInstance("Plugins");
        
        EntityValue entityValue = (EntityValue) fruitEntityInstance.getInstanceReference();
        IPrimitiveValue[] fruitTreeBefore = FormsUtils.getAttrMultiValue(context, entityValue, "FruitTree");
        assertNotNull(fruitTreeBefore);
        assertEquals(5, fruitTreeBefore.length);
        assertEquals("Lemon", (fruitTreeBefore[2]).getValue());                
        
        String positionBefore = FormsUtils.getAttr(context, "Plugins", "Position");
        assertEquals("2", positionBefore);
        
        service.handle(context);
        
        String attrAfter = FormsUtils.getAttr(context, "Plugins", "ReturnedValueFromFruits");
        assertNotNull(attrAfter);
        assertEquals("Lemon", attrAfter);        
    }

    @Test
    public void testGetValueFromArrayHappyFlow() throws Exception {    	
    	// create model
    	ApplicationTemplate applicationTemplate = createApplication();
				
		// set service parameters
		ServiceContextTemplate serviceContext = new ServiceContextTemplate(applicationTemplate);
		serviceContext.addParameter("multi-value", "MyArray.Toys");
		serviceContext.addParameter("position", "MyPosition.Number");
		serviceContext.addParameter("result", "MyResult.TheResult");
		IServiceContext context = serviceContext.toContext();

		// set attributes
		List<String> list = setMyArray(context);		
		IEntityInstance positionInstance = context.getProfile().getSingletonInstance("MyPosition", true);
		positionInstance.setValue("Number", "2");
		
		// run plugin
		service.handle(context);
		
		// test result value
		String attrAfter = FormsUtils.getAttr(context, "MyResult", "TheResult");
        assertNotNull(attrAfter);
        assertEquals("Animals", attrAfter); 
    }
    
    @Test
    public void testGetValueFromArrayInvalidPosition() throws Exception {    	
    	// create model
    	ApplicationTemplate applicationTemplate = createApplication();
				
		// set service parameters
		ServiceContextTemplate serviceContext = new ServiceContextTemplate(applicationTemplate);
		serviceContext.addParameter("multi-value", "MyArray.Toys");
		serviceContext.addParameter("position", "MyPosition.Number");
		serviceContext.addParameter("result", "MyResult.TheResult");
		IServiceContext context = serviceContext.toContext();
		
		// set attributes
		List<String> list = setMyArray(context);		
		IEntityInstance positionInstance = context.getProfile().getSingletonInstance("MyPosition", true);
		positionInstance.setValue("Number", "6");
		
		// run plugin
		service.handle(context);
		
		// test result value
		String attrAfter = FormsUtils.getAttr(context, "MyResult", "TheResult");
        assertNotNull(attrAfter);
        assertEquals("", attrAfter); 
    }
    
    @Test
    public void testGetValueFromArrayOverwriteValues() throws Exception {    	
    	// create model
    	ApplicationTemplate applicationTemplate = createApplication();
				
		// set service parameters
		ServiceContextTemplate serviceContext = new ServiceContextTemplate(applicationTemplate);
		serviceContext.addParameter("multi-value", "MyArray.Toys");
		serviceContext.addParameter("position", "MyPosition.Number");
		serviceContext.addParameter("result", "MyResult.TheResult");
		IServiceContext context = serviceContext.toContext();
		
		// set attributes
		List<String> list = setMyArray(context);		
		IEntityInstance positionInstance = context.getProfile().getSingletonInstance("MyPosition", true);
		positionInstance.setValue("Number", "1");
		
		// run plugin
		service.handle(context);
		
		// test result value
		String attrAfter = FormsUtils.getAttr(context, "MyResult", "TheResult");
        assertNotNull(attrAfter);
        assertEquals("Cars", attrAfter); 
        
        // Rerun with wrong value, check if result is empty string
        positionInstance.setValue("Number", "-1");
		// run plugin
		service.handle(context);		
		// test result value
		attrAfter = FormsUtils.getAttr(context, "MyResult", "TheResult");
		assertNotNull(attrAfter);
		assertEquals("", attrAfter);
		
        // Rerun with position=0
        positionInstance.setValue("Number", "0");
		// run plugin
		service.handle(context);		
		// test result value
		attrAfter = FormsUtils.getAttr(context, "MyResult", "TheResult");
		assertNotNull(attrAfter);
		assertEquals("Blocks", attrAfter);
		
        // Rerun with position=length of list
		positionInstance.setValue("Number", list.size());
		// run plugin
		service.handle(context);		
		// test result value
		attrAfter = FormsUtils.getAttr(context, "MyResult", "TheResult");
		assertNotNull(attrAfter);
		assertEquals("", attrAfter);
		
        // Rerun with position=length of list minus 1
		positionInstance.setValue("Number", list.size() - 1);
		// run plugin
		service.handle(context);		
		// test result value
		attrAfter = FormsUtils.getAttr(context, "MyResult", "TheResult");
		assertNotNull(attrAfter);
		assertEquals("Animals", attrAfter);
    }

	private List<String> setMyArray(IServiceContext context) {
		IEntityInstance arrayInstance = context.getProfile().getSingletonInstance("MyArray", true);
		List<String> list = new ArrayList<String>();
		list.add("Blocks");
		list.add("Cars");
		list.add("Animals");	
		arrayInstance.setValue("Toys", list);
		return list;
	}
    
    private ApplicationTemplate createApplication() {
		// create application with entities and attributes
    	ApplicationTemplate applicationTemplate = new ApplicationTemplate();
		
		//MyArray.Toys
		EntityTemplate arrayEntity = applicationTemplate.getMetaModel().addEntity("MyArray", null, true);
		arrayEntity.addAttribute("Toys", DataType.STRING, true); 
	
		//MyPosition.Number
		EntityTemplate positionEntity = applicationTemplate.getMetaModel().addEntity("MyPosition", null, true);
		positionEntity.addAttribute("Number", DataType.INTEGER, false);
	
		//MyResult.TheResult
		EntityTemplate resultEntity = applicationTemplate.getMetaModel().addEntity("MyResult", null, true);
		resultEntity.addAttribute("TheResult", DataType.STRING, false);
			
		return applicationTemplate;
	}
}
