package com.backbase.expert.forms.extensions.services;

import com.aquima.interactions.portal.IService;
import com.aquima.interactions.portal.IServiceContext;
import com.aquima.interactions.profile.IEntityInstance;
import com.aquima.interactions.rule.InferenceContext;
import com.backbase.expert.forms.context.AquimaContextLoader;
import com.backbase.expert.forms.extensions.utils.FormsUtils;
import org.junit.Before;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.*;

/**
 * Test class for SetAttributeService.
 *
 * @author Dirk Gietelink [dirk]
 * @since 2015-10-01
 */
public class SetAttributeServiceTest extends AquimaContextLoader {

    private static final String projectZipPath = "/exports/TOM.project.zip";
    private static final String profileXmlPath = "/exports/TOM.step2.profile.xml";
    
    private IService service;
    private IServiceContext context;
    
    @Before
    public void setup() throws Exception {
        String serviceCallName = "WhateverServiceName";
        String serviceTypeName = "BB_SetAttribute";
        Map<String, String> expressionParameters = createExpressionParameterMap();
        Map<String, String> valueParameters = null;

        context = loadFullContext(projectZipPath, profileXmlPath, serviceCallName, serviceTypeName, 
                valueParameters, expressionParameters);
        service = new SetAttributeService();
    }

    private Map<String,String> createExpressionParameterMap() {
        Map<String, String> params = new HashMap<String, String>();
        params.put("target-attribute-path", "Check.HomePage");
        params.put("value", "\"http://www.setAttribute.com\"");
        return params;
    }
    
    @Test
    public void testSetAttributeHappyPath() throws Exception {
        InferenceContext profile = context.getProfile();
        assertNotNull(profile);
        IEntityInstance check = profile.getActiveInstance("Check");
        assertNotNull(check);
        String attrBefore = FormsUtils.getAttr(check, "HomePage");
        String newAttrValue = "http://www.setAttribute.com";
        assertNotEquals(newAttrValue, attrBefore);
        service.handle(context);
        String attrAfter = FormsUtils.getAttr(check, "HomePage");
        assertEquals(newAttrValue, attrAfter);
    }
    
    // TODO test boolean, null, numbers, encoding, etc.
    //        assertEquals("36", FormsUtils.getAttr(customer, "Age"));
    
}
