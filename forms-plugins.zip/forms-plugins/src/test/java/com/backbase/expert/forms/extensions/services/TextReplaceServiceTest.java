package com.backbase.expert.forms.extensions.services;

import com.aquima.interactions.portal.IService;
import com.aquima.interactions.portal.IServiceContext;
import com.aquima.interactions.rule.InferenceContext;
import com.backbase.expert.forms.context.AquimaContextLoader;
import com.backbase.expert.forms.extensions.utils.FormsUtils;
import org.junit.Before;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

/**
 * Test class for TextReplaceService.
 *
 * @author Dirk Gietelink [dirk]
 * @since 2015-10-06
 */
public class TextReplaceServiceTest extends AquimaContextLoader {

    private static final String projectZipPath = "/exports/Plugins.project.zip";
    private static final String profileXmlPath = "/exports/Start_Plugins.all-loaded.profile.xml";

    private IService service;
    private IServiceContext context;

    @Before
    public void setup() throws Exception {
        String serviceCallName = "WhateverServiceName";
        String serviceTypeName = "BB_TextReplace";
        Map<String, String> expressionParameters = createExpressionParameterMap();
        Map<String, String> valueParameters = createValueParameterMap();

        context = loadFullContext(projectZipPath, profileXmlPath, serviceCallName, serviceTypeName,
                valueParameters, expressionParameters);
        service = new TextReplaceService();
    }

    private Map<String,String> createExpressionParameterMap() {
        Map<String, String> params = new HashMap<String, String>();
        params.put("SourceString", "Plugins.ReplaceText");  // Plugins.ReplaceText = Apple for scale
        params.put("Result", "Plugins.ReplaceResult");
        return params;
    }

    private Map<String,String> createValueParameterMap() {
        Map<String, String> params = new HashMap<String, String>();
        params.put("StringToFind", "Apple");
        params.put("StringToReplace", "Banana");
        return params;
    }

    @Test
    public void testTextReplaceHappyPath() throws Exception {
        InferenceContext profile = context.getProfile();
        assertNotNull(profile);
        String textExtractBefore = FormsUtils.getAttr(context, "Plugins", "ReplaceText");
        assertEquals("Apple for scale", textExtractBefore);
        String resultBefore = FormsUtils.getAttr(context, "Plugins", "ReplaceResult");
        assertNull(resultBefore);
        service.handle(context);
        String resultAfter = FormsUtils.getAttr(context, "Plugins", "ReplaceResult");
        assertNotNull(resultAfter);
        assertEquals("Banana for scale", resultAfter);
    }


}
