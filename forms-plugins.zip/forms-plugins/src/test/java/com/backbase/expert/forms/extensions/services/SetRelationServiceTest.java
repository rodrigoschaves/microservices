package com.backbase.expert.forms.extensions.services;

import com.aquima.interactions.portal.IService;
import com.aquima.interactions.portal.IServiceContext;
import com.aquima.interactions.profile.IEntityInstance;
import com.aquima.interactions.rule.InferenceContext;
import com.backbase.expert.forms.context.AquimaContextLoader;
import com.backbase.expert.forms.extensions.utils.FormsUtils;
import org.junit.Before;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.*;

/**
 * Test class for SetRelationService.
 *
 * @author Dirk Gietelink [dirk]
 * @since 2015-10-06
 */
public class SetRelationServiceTest extends AquimaContextLoader {

    private static final String projectZipPath = "/exports/TOM.project.zip";
    private static final String profileXmlPath = "/exports/TOM.before-SetRelation.profile.xml";

    private IService service;
    private IServiceContext context;

    @Before
    public void setup() throws Exception {
        String serviceCallName = "WhateverServiceName";
        String serviceTypeName = "BB_SetRelation";
        Map<String, String> expressionParameters = createExpressionParameterMap();
        Map<String, String> valueParameters = createValueParameterMap();

        context = loadFullContext(projectZipPath, profileXmlPath, serviceCallName, serviceTypeName,
                valueParameters, expressionParameters);
        
        // activate one of the Products
        FormsUtils.activateInstanceByUUID(context, "Product", "35c0b9cc-2c3a-41b9-9b0f-9abcfdd16e3f");
        
        service = new SetRelationService();
    }

     private Map<String,String> createExpressionParameterMap() {
        Map<String, String> params = new HashMap<String, String>();
        params.put("instances", "Product");
        return params;
    }
    
    private Map<String,String> createValueParameterMap() {
        Map<String, String> params = new HashMap<String, String>();
        params.put("relation-path", "Policy.ProductDetails");
        params.put("add-to-relation", "false");
        return params;
    }

    @Test
    public void testSetRelationHappyPath() throws Exception {
        InferenceContext profile = context.getProfile();
        assertNotNull(profile);
        IEntityInstance[] coversBefore = profile.getAllInstancesForEntity("Cover", true);
        assertEquals(0, coversBefore.length);
        IEntityInstance policy = profile.getActiveInstance("Policy");
        assertNotNull(policy);
        IEntityInstance productDetailsBefore = policy.getInstanceValue("ProductDetails");
        assertNull(productDetailsBefore);

        service.handle(context);

        IEntityInstance productDetailsAfter = policy.getInstanceValue("ProductDetails");
        assertNotNull(productDetailsAfter);
        assertEquals("35c0b9cc-2c3a-41b9-9b0f-9abcfdd16e3f", productDetailsAfter.getId().getValue());
    }

}
