package com.backbase.expert.forms.context;

import com.aquima.interactions.foundation.io.IResource;
import com.aquima.interactions.foundation.io.resource.FileResource;
import com.aquima.interactions.metamodel.IMetaModel;
import com.aquima.interactions.metamodel.ds.IMetaModelDS;
import com.aquima.interactions.metamodel.impl.MetaModel;
import com.aquima.interactions.portal.IServiceContext;
import com.aquima.interactions.portal.model.def.TypedParameter;
import com.aquima.interactions.portal.model.def.TypedParameters;
import com.aquima.interactions.profile.IProfile;
import com.aquima.interactions.profile.xml.XmlConverter;
import com.aquima.interactions.project.ParameterType;
import com.aquima.interactions.rule.IExpressionParser;
import com.aquima.interactions.test.templates.ApplicationExportTemplate;
import com.aquima.interactions.test.templates.EngineFactory;
import com.aquima.interactions.test.templates.IApplicationTemplate;
import com.aquima.interactions.test.templates.context.ServiceContextTemplate;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Map;

/**
 * Abstract class for unit tests, where a session profile needs
 * to be loaded in the Forms Runtime IServiceContext.<p>
 * 
 * You can export a profile at Runtime (see Debug bar > Profile > Profile Import/Export) 
 * and import this in a unit test, by calling the loadFullContext() method of this class.<p>
 * 
 * Extending classes should implement unit tests in the following manner:
 * 
 * <pre>
 *  public void testImportedXml() throws Exception {
 *      IApplicationTemplate app = createApplicationTemplate("projectX.zip");
 *      final IServiceContext context = loadFullContext(app, "/profile.xml");
 *      IService dummyPlugin = new DummyService();
 *      dummyPlugin.handle(context);
 *      Assert.assertEquals("expected", FormsUtils.getAttr(context, "entityName", "attrName"));
 *  }
 * </pre>
 *
 * @author Dirk Gietelink [dirk]
 * @since 2015-10-01
 */
@ContextConfiguration(locations = "classpath:/spring/test-context.xml", loader = CustomXmlContextLoader.class)
public abstract class AquimaContextLoader extends AbstractJUnit4SpringContextTests {

    private static final Logger LOG = LoggerFactory.getLogger(AquimaContextLoader.class);
    
    private String serviceCallName;
    private String serviceTypeName;
    private IApplicationTemplate applicationTemplate;
    protected Map<String, String> valueParameters;
    protected Map<String, String> expressionParameters;

    public IApplicationTemplate getApplicationTemplate() {
        return applicationTemplate;
    }

    public void setApplicationTemplate(IApplicationTemplate applicationTemplate) {
        this.applicationTemplate = applicationTemplate;
    }

    /**
     * Convenience method to load a full ServiceContext from a project zip and an exported profile xml.
     * 
     * @param projectZipPath
     * @param profileXmlPath
     * @param serviceCallName
     * @param serviceTypeName
     * @param valueParameters
     * @param expressionParameters
     * @return
     * @throws IOException
     * @throws URISyntaxException
     */
    protected IServiceContext loadFullContext(String projectZipPath, String profileXmlPath,
                                            String serviceCallName, String serviceTypeName, 
                                            Map<String, String> valueParameters,
                                            Map<String, String> expressionParameters)
            throws IOException, URISyntaxException {
        this.serviceCallName = serviceCallName;
        this.serviceTypeName = serviceTypeName;
        this.valueParameters = valueParameters;
        this.expressionParameters = expressionParameters;
        return loadFullContext(projectZipPath, profileXmlPath);
    }

    /**
     * Convenience method to load a full ServiceContext from an Application Template and an exported profile xml.
     * 
     * @param app
     * @param profileXmlPath
     * @param serviceCallName
     * @param serviceTypeName
     * @param valueParameters
     * @param expressionParameters
     * @return
     * @throws IOException
     * @throws URISyntaxException
     */
    protected IServiceContext loadFullContext(IApplicationTemplate app, String profileXmlPath,
                                            String serviceCallName, String serviceTypeName,
                                            Map<String, String> valueParameters,
                                            Map<String, String> expressionParameters)
            throws IOException, URISyntaxException {
        this.serviceCallName = serviceCallName;
        this.serviceTypeName = serviceTypeName;
        this.valueParameters = valueParameters;
        this.expressionParameters = expressionParameters;
        return loadFullContext(app, profileXmlPath);
    }

    /**
     * Convenience method to load a full ServiceContext from a project zip and an exported profile xml.
     * 
     * @param projectZipPath
     * @param profileXmlPath
     * @return
     * @throws IOException
     */
    protected IServiceContext loadFullContext(String projectZipPath, String profileXmlPath) throws IOException, URISyntaxException {
        // App
        applicationTemplate = createApplicationTemplate(projectZipPath);
        // Get model
        IMetaModel model = initModel(applicationTemplate);
        // Context
        IServiceContext context = initServiceContext(applicationTemplate, serviceCallName, serviceTypeName);
        // User profile
        IProfile profile = loadUserProfile(context.getProfile(), model, profileXmlPath);
        // Manipulate the context
        manipulateContext(context);
        
        return context;
    }


    /**
     * Convenience method to load a full ServiceContext from an Application Template and an exported profile xml.
     * 
     * @param applicationTemplate
     * @param profileXmlPath
     * @return
     * @throws IOException
     */
    protected IServiceContext loadFullContext(IApplicationTemplate applicationTemplate, String profileXmlPath) throws IOException {
        // Get model
        IMetaModel model = initModel(applicationTemplate);
        // Context
        IServiceContext context = initServiceContext(applicationTemplate, serviceCallName, serviceTypeName);
        // User profile
        IProfile profile = loadUserProfile(context.getProfile(), model, profileXmlPath);
        // Manipulate the context
        manipulateContext(context);
        
        return context;
    }


    /**
     * Manipulate the Forms context, before executing a test. 
     * Leave the method with an empty body to keep the initially loaded context and profile.
     *
     * @param context
     */
    protected void manipulateContext(IServiceContext context) {
        LOG.debug("No manipulations are done to loaded forms context. Override manipulateContext() to do so.");
    }


    /**
     * 
     * @param app
     * @param serviceCallName
     * @param serviceTypeName
     * @return
     */
    protected IServiceContext initServiceContext(IApplicationTemplate app, String serviceCallName, String serviceTypeName) {
        ServiceContextTemplate serviceContextTemplate = new ServiceContextTemplate(app);
        serviceContextTemplate.setParameters(createExpressionParameters(expressionParameters, valueParameters));
        
        serviceContextTemplate.setServiceCallName(serviceCallName);
        serviceContextTemplate.setServiceTypeName(serviceTypeName);
        return serviceContextTemplate.toContext();
    }

    /**
     * 
     * @param projectZipPath
     * @return
     * @throws IOException
     * @throws URISyntaxException
     */
    protected IApplicationTemplate createApplicationTemplate(String projectZipPath) throws IOException, URISyntaxException {
        URL url = this.getClass().getResource(projectZipPath);
        File file = new File(url.toURI());
        IResource resource = new FileResource(file);
        ApplicationExportTemplate withExport = ApplicationExportTemplate.createWithR8ZipExport(resource);
        return withExport;
    }

    /**
     * 
     * @param app
     * @return
     */
    protected IMetaModel initModel(IApplicationTemplate app) {
        final IMetaModelDS metaModelDS = app.toAppDataSource().getMetaModelDS();
        return new MetaModel(metaModelDS);
    }

    /**
     * 
     * @param model
     * @param profileXmlPath
     * @return
     * @throws IOException
     */
    protected IProfile loadUserProfile(IProfile userProfile, IMetaModel model, String profileXmlPath) throws IOException {
        InputStream inputStream = this.getClass().getResourceAsStream(profileXmlPath);
        String xml = IOUtils.toString(inputStream);
        XmlConverter xmlConverter = new XmlConverter(model);
        xmlConverter.importXml(userProfile, xml);
        return userProfile;
    }

    /**
     * Converts a HashMap of expression parameters to the TypedParameters object.
     * 
     *
     * @param expressionParameters
     * @param valueParameters
     * @return
     */
    private TypedParameters createExpressionParameters(Map<String, String> expressionParameters, Map<String, String> valueParameters) {
        IExpressionParser expressionParser = EngineFactory.createRuleEngine(getApplicationTemplate()).getExpressionParser();
        TypedParameters parameters = new TypedParameters(true);

        if(expressionParameters != null) {
            for(String key : expressionParameters.keySet()) {
                addExpressionParameter(parameters, expressionParser, key, expressionParameters.get(key));
            }
        }
        if(valueParameters != null) {
            for(String key : valueParameters.keySet()) {
                parameters.setParameter(key, valueParameters.get(key));
            }
        }
        return parameters;
    }

    /**
     * Creates a single TypedParameter of type Expression, and adds it to the TypedParameters aggregation object.
     * 
     * @param parameters
     * @param expressionParser
     * @param key
     * @param expressionString
     */
    private void addExpressionParameter(TypedParameters parameters, IExpressionParser expressionParser, String key, String expressionString) {
        TypedParameter typedParameter = new TypedParameter(key, ParameterType.EXPRESSION);
        typedParameter.addParameterValue(null, expressionParser.expressionFor(expressionString));
        parameters.setTypedParameter(key, typedParameter);
    }


}
