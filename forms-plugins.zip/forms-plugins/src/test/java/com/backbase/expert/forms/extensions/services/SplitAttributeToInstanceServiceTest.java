package com.backbase.expert.forms.extensions.services;

import com.aquima.interactions.portal.IService;
import com.aquima.interactions.portal.IServiceContext;
import com.aquima.interactions.profile.IEntityInstance;
import com.aquima.interactions.rule.InferenceContext;
import com.backbase.expert.forms.context.AquimaContextLoader;
import com.backbase.expert.forms.extensions.utils.FormsUtils;
import org.junit.Before;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.*;

/**
 * Test class for SplitAttributeToInstanceService.
 *
 * @author Dirk Gietelink [dirk]
 * @since 2015-10-06
 */
public class SplitAttributeToInstanceServiceTest extends AquimaContextLoader {

    private static final String projectZipPath = "/exports/Plugins.project.zip";
    private static final String profileXmlPath = "/exports/Start_Plugins.all-loaded.profile.xml";

    private IService service;
    private IServiceContext context;

    @Before
    public void setup() throws Exception {
        String serviceCallName = "WhateverServiceName";
        String serviceTypeName = "BB_SplitAttributeToInstance";
        Map<String, String> expressionParameters = createExpressionParameterMap();
        Map<String, String> valueParameters = createValueParameterMap();

        context = loadFullContext(projectZipPath, profileXmlPath, serviceCallName, serviceTypeName,
                valueParameters, expressionParameters);
        service = new SplitAttributeToInstance();
    }

    private Map<String,String> createExpressionParameterMap() {
        Map<String, String> params = new HashMap<String, String>();
        params.put("split-flag", "Plugins.SplitSymbol");
        params.put("split-string", "Plugins.SplitString");
        return params;
    }
    
    private Map<String,String> createValueParameterMap() {
        Map<String, String> params = new HashMap<String, String>();
        params.put("relation", "Plugins.r_SplitResult");
        params.put("target-instance", "SplitResult");
        params.put("target-attribute", "SplitResult.Value");
        return params;
    }
    
    @Test
    public void testSplitAttributeToInstanceHappyPath() throws Exception {
        InferenceContext profile = context.getProfile();
        assertNotNull(profile);
        String attrBefore = FormsUtils.getAttr(context, "Plugins", "r_SplitResult");
        assertNull(attrBefore);
        service.handle(context);
        IEntityInstance[] splittedValues = profile.getActiveInstance("Plugins").getInstanceValues("r_splitresult");
        assertEquals(8, splittedValues.length);
        
        assertSplitted(splittedValues, 0, "({{param1}}.indexOf('Colon cancer') !== -1)) ");
        assertSplitted(splittedValues, 1, " (({{param2}}.indexOf('Colon cancer') !== -1)) ");
        assertSplitted(splittedValues, 2, " (({{param3}}.indexOf('Ovarian cancer') !== -1)) ");
        assertSplitted(splittedValues, 3, " (({{param4}}.indexOf('Breast cancer') !== -1)) ");
        assertSplitted(splittedValues, 4, " (({{param5}}.indexOf('Huntington\\'s disease') !== -1)) ");
        assertSplitted(splittedValues, 5, " (({{param6}}.indexOf('Muscular dystrophy') !== -1)) ");
        assertSplitted(splittedValues, 6, " (({{param7}}.indexOf('Spinocerebellar degenerations') !== -1)) ");
        assertSplitted(splittedValues, 7, " (({{param8}}.indexOf('Cardiomyopathies') !== -1))");
    }

    private static void assertSplitted(IEntityInstance[] splittedValues, int index, String expected) {
        System.out.println("Checking splitted[] index " + index);
        assertNotNull(splittedValues);
        IEntityInstance split = splittedValues[index];
        String result_param = FormsUtils.getAttr(split, "param");
        String result_value = FormsUtils.getAttr(split, "value");
        assertNull(result_param);
        assertNotNull(result_value);
        assertEquals(expected, result_value);
    }

}
