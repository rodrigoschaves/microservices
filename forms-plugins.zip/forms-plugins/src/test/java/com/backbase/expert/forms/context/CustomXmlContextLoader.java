package com.backbase.expert.forms.context;

import org.springframework.context.support.GenericApplicationContext;
import org.springframework.core.env.PropertySource;
import org.springframework.mock.env.MockPropertySource;
import org.springframework.test.context.support.GenericXmlContextLoader;

/**
 * Class description.
 *
 * @author Dirk Gietelink [dirk]
 * @since 2015-10-07
 */
public class CustomXmlContextLoader extends GenericXmlContextLoader {
    @Override
    protected void customizeContext(GenericApplicationContext context) {
//        ClassPathXmlApplicationContext propertySourceContext =
//                new ClassPathXmlApplicationContext("classpath:/aquima-plugin-context.xml");

        PropertySource propertySource = new MockPropertySource();

        context.getEnvironment().getPropertySources().addFirst(propertySource);
    }
}