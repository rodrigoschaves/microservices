package com.backbase.expert.forms.extensions.services;

import com.aquima.interactions.portal.IService;
import com.aquima.interactions.portal.IServiceContext;
import com.aquima.interactions.rule.InferenceContext;
import com.backbase.expert.forms.context.AquimaContextLoader;
import com.backbase.expert.forms.extensions.utils.FormsUtils;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.*;

/**
 * Test class for HttpSessionService.
 *
 * @author Dirk Gietelink [dirk]
 * @since 2015-10-06
 */
public class HttpSessionServiceTest extends AquimaContextLoader {

    private static final String projectZipPath = "/exports/Plugins.project.zip";
    private static final String profileXmlPath = "/exports/Start_Plugins.all-loaded.profile.xml";

    private IService service;
    private IServiceContext context;

//    @Before
    public void setup(String fromOrTo, String attrName) throws Exception {
        String serviceCallName = "WhateverServiceName";
        String serviceTypeName = "BB_HttpSession";
        Map<String, String> expressionParameters = createExpressionParameterMap(attrName);
        Map<String, String> valueParameters = createValueParameterMap(fromOrTo);

        context = loadFullContext(projectZipPath, profileXmlPath, serviceCallName, serviceTypeName,
                valueParameters, expressionParameters);
        service = new HttpSessionService();
    }

    private Map<String,String> createExpressionParameterMap(String attrName) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("target-attribute-path", attrName);
        return params;
    }

    private Map<String,String> createValueParameterMap(String fromOrTo) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("from-or-to", fromOrTo);
        return params;
    }

    @Test
    public void testFromSession() throws Exception {
        setup("from", "Plugins.textextractresult");
        InferenceContext profile = context.getProfile();
        assertNotNull(profile);
        context.getUserScope().setAttribute("Plugins.textextractresult", "Some string sitting sin session scope");
        String attrBefore = FormsUtils.getAttr(context, "Plugins", "textextractresult");
        assertNull(attrBefore);

        // from session
        service.handle(context);

        String attrAfter = FormsUtils.getAttr(context, "Plugins", "textextractresult");
        assertNotNull(attrAfter);
        assertEquals("Some string sitting sin session scope", attrAfter);
        System.out.println(attrAfter);
    }

    @Test
    public void testToSession() throws Exception {
        setup("to", "Plugins.textextractbefore");
        InferenceContext profile = context.getProfile();
        assertNotNull(profile);
        assertNull(context.getUserScope().getAttribute("Plugins.textextractbefore"));
        String attrBefore = FormsUtils.getAttr(context, "Plugins", "textextractbefore");
        assertEquals(attrBefore, "MinionSupportDesk");
        System.out.println(attrBefore);

        // to session
        service.handle(context);

        String attrAfter = (String) context.getUserScope().getAttribute("Plugins.textextractbefore");
        assertEquals("MinionSupportDesk", attrAfter);
        System.out.println(attrAfter);
    }

}
