package com.backbase.expert.forms.extensions.services;

import com.aquima.interactions.portal.IErrorMessage;
import com.aquima.interactions.portal.IService;
import com.aquima.interactions.portal.IServiceContext;
import com.aquima.interactions.rule.InferenceContext;
import com.backbase.expert.forms.context.AquimaContextLoader;
import org.junit.Before;
import org.junit.Test;

import java.util.Map;

import static org.junit.Assert.*;

/**
 * Test class for ClearServiceError.
 *
 * @author Dirk Gietelink [dirk]
 * @since 2015-10-06
 */
public class ClearServiceErrorTest extends AquimaContextLoader {

    private static final String projectZipPath = "/exports/Plugins.project.zip";
    private static final String profileXmlPath = "/exports/Start_Plugins.all-loaded.profile.xml";

    private IService service;
    private IServiceContext context;

    @Before
    public void setup() throws Exception {
        String serviceCallName = "WhateverServiceName";

        Map<String, String> expressionParameters = null;
        Map<String, String> valueParameters = null;
        
        context = loadFullContext(projectZipPath, profileXmlPath, serviceCallName, "BB_ClearServiceError",
                valueParameters, expressionParameters);
        service = new ClearServiceError();
    }

    @Test
    public void testClearErrorsHappyPath() throws Exception {
        InferenceContext profile = context.getProfile();
        assertNotNull(profile);
        
        assertTrue(context.getStopOnErrors());

        service.handle(context);

        IErrorMessage[] errorsAfter = context.getErrors(true);
        assertEquals(0, errorsAfter.length);
        assertFalse(context.getStopOnErrors());

    }


}
