package com.backbase.expert.forms.examples.plugin;

import com.aquima.interactions.foundation.DataType;
import com.aquima.interactions.foundation.text.MultilingualText;
import com.aquima.interactions.foundation.types.ListValue;
import com.aquima.interactions.foundation.types.StringValue;
import com.aquima.web.config.annotation.AquimaDomain;

//inladen bij 1e keer laden project.
@AquimaDomain("NameOfValueList")
public class ExternalValueList extends ListValue{

	public ExternalValueList() {
		super(DataType.STRING);

		//waarde met andere text
		MultilingualText multilingualText = new MultilingualText();
		multilingualText.addContent("nl-NL", "Man");
		multilingualText.addContent("en-GB", "Male");
		super.addValue(new StringValue("NameOfValueList", multilingualText, "m"));

		multilingualText = new MultilingualText();
		multilingualText.addContent("nl-NL", "Vrouw");
		multilingualText.addContent("en-GB", "Female");
		super.addValue(new StringValue("NameOfValueList", multilingualText, "f"));

		//caption = waarde
		super.addValue(new StringValue("Unknown"));
	}

}
