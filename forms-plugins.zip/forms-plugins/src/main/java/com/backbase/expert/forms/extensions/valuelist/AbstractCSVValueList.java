package com.backbase.expert.forms.extensions.valuelist;

import au.com.bytecode.opencsv.CSVReader;
import com.aquima.interactions.foundation.DataType;
import com.aquima.interactions.foundation.text.MultilingualText;
import com.aquima.interactions.foundation.types.*;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.List;

/**
 * Abstract class for loading a dynamic ValueList at runtime.
 * 
 * @author Dirk Gietelink [dirk]
 * @since 2014-01-31
 */
public abstract class AbstractCSVValueList extends ListValue {

	private static final long serialVersionUID = -3595907163250981684L;

	private static final Logger LOG = LoggerFactory.getLogger(AbstractCSVValueList.class);

	private static final String ENCODING_UTF8 = "UTF-8";

	public static final String DEFAULT_JAVA_LOCALE = "en_GB";
	public static final String DEFAULT_FORMS_LOCALE = "en-GB";

	/**
	 * Default constructor
	 */
	public AbstractCSVValueList() {
		super(DataType.STRING);
	}

	/**
     * Loads the values of a CSV into a Forms Runtime ValueList.
     * 
	 * @param filePathAbsolute
	 * @param filePathRelative
	 * @param typeName
	 * @param columnIndexInternalValue
	 * @param columnIndexDisplayValue
	 * @param columnIndexLocaleValue
	 * @param separatorChar
	 * @param quoteChar
	 * @param lineSkipToStart
	 * @param locale
	 */
	protected void loadValues(String filePathAbsolute, String filePathRelative,
			String typeName, int columnIndexInternalValue,
			int columnIndexDisplayValue, int columnIndexLocaleValue,
			char separatorChar, char quoteChar, int lineSkipToStart) {
		LOG.info("Constructing new Forms ValueList: {}", typeName);

		List<String[]> csvList = loadCSV(filePathAbsolute, filePathRelative,
				separatorChar, quoteChar, lineSkipToStart);

		loadDataIntoValueList(csvList, typeName, columnIndexInternalValue,
				columnIndexDisplayValue, columnIndexLocaleValue);

		LOG.info("Finished construction of ValueList of type: {}", typeName);
	}

	/**
	 * Loads a CSV file.
	 * 
	 * @param filenameAbsolute
	 * @param filenameRelative
	 * @param separatorChar
	 * @param quoteChar
	 * @param lineSkipToStart
	 * @return
	 */
	private List<String[]> loadCSV(String filenameAbsolute, String filenameRelative,
			char separatorChar, char quoteChar, int lineSkipToStart) {
		LOG.debug("loadCSV");
		List<String[]> csvList = null;
		CSVReader reader = null;

		try {
			InputStream inputStream = getInputStream(filenameAbsolute, filenameRelative);
			if (inputStream != null) {
				reader = new CSVReader(
                        new InputStreamReader(inputStream, ENCODING_UTF8), separatorChar, quoteChar, lineSkipToStart);
				csvList = reader.readAll();
			}
		} catch (IOException e) {
			LOG.error("Problem while reading the CSV file", e);
		} finally {
			IOUtils.closeQuietly(reader);
		}
		return csvList;
	}

	/**
	 * Persist an in-memory CSV List of String arrays into a dynamic Forms
	 * ValueList.
	 * 
	 * @param csvList
	 * @param typeName
	 * @param columnIndexDisplayValue
	 * @param columnIndexInternalValue
	 * @param columnIndexLocaleValue
	 */
	private void loadDataIntoValueList(List<String[]> csvList, String typeName,
			int columnIndexInternalValue, int columnIndexDisplayValue,
			int columnIndexLocaleValue) {
		LOG.debug("loadDataIntoValueList");

		LOG.debug("columnIndexInternalValue: {}", columnIndexInternalValue);
		LOG.debug("columnIndexDisplayValue: {}", columnIndexDisplayValue);
		LOG.debug("columnIndexLocaleValue: {}", columnIndexLocaleValue);

		if ((columnIndexInternalValue < 0) || (columnIndexDisplayValue < 0)) {
			throw new IllegalArgumentException("CSV value and display columns are not valid");
		}

		for (String[] row : csvList) {
			LOG.debug("row: {}", Arrays.toString(row));

			if ((columnIndexInternalValue >= row.length) || (columnIndexDisplayValue >= row.length)) {
				throw new IllegalArgumentException("CSV value and display columns are not valid");
			}

			MultilingualText multilingualText = new MultilingualText();

			String locale = null;
			if (columnIndexLocaleValue >= 0) {
				locale = row[columnIndexLocaleValue];
				LOG.debug("locale: {}", locale);
			}

			String rowLocale = StringUtils.defaultString(locale, DEFAULT_FORMS_LOCALE);
			LOG.debug("rowLocale: {}", rowLocale);

			String displayValue = row[columnIndexDisplayValue];
			LOG.debug("displayValue: {}", displayValue);

			multilingualText.addContent(rowLocale, displayValue);

			String value = row[columnIndexInternalValue];
			LOG.debug("value: {}", value);

			super.addValue(new StringValue(typeName, multilingualText, value));
		}
	}

	/**
	 * Returns an InputStream for a file with filePath.
	 * 
	 * @param filePathAbsolute
	 *            - segment of absolute path to the file
	 *            ("C:/dev/Hiscox/forms/forms-home-dev/plugins/")
	 * @param filePathRelative
	 *            - classpath to the file
	 *            ("com/backbase/forms/dynamic/Occupation.csv")
	 * @return
	 */
	private InputStream getInputStream(String filePathAbsolute,	String filePathRelative) {
		LOG.debug("getInputStream");
		InputStream inputStream = null;

		if (!StringUtils.isEmpty(filePathAbsolute)) {
            LOG.debug("Try loading ValueList from filesystem path");
            String filePath = constructFilePath(filePathAbsolute, filePathRelative);
			File file = new File(filePath);
			if(file.exists()){
				try {
					inputStream = new FileInputStream(new File(filePath));
					LOG.debug("Loading ValueList from filepath: {}", filePath);
				} catch (FileNotFoundException e) {
					LOG.error("File {} does not exist", filePath);
				}
			} else {
				LOG.error("File {} does not exist", filePath);
			}
		}
		if(inputStream == null){
			LOG.debug("Loading ValueList from classpath: {}", filePathRelative);
			inputStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(filePathRelative);
		}
		return inputStream;
	}

    /**
     * Constructs the filesystem path.
     * @param filePathAbsolute
     * @param filePathRelative
     * @return
     */
    private String constructFilePath(String filePathAbsolute, String filePathRelative) {
        StringBuffer filePath = new StringBuffer().append(filePathAbsolute);
        if(filePath.toString().endsWith("/")) {
            filePath.append(filePathRelative);
        } else {
            filePath.append("/").append(filePathRelative);
        }
        return filePath.toString();
    }
}
