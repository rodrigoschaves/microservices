package com.backbase.expert.forms.extensions.services;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aquima.interactions.foundation.IPrimitiveValue;
import com.aquima.interactions.foundation.IValue;
import com.aquima.interactions.framework.service.ServiceResult;
import com.aquima.interactions.portal.IService;
import com.aquima.interactions.portal.IServiceContext;
import com.aquima.interactions.portal.IServiceResult;
import com.aquima.web.config.annotation.AquimaService;
import com.backbase.expert.forms.extensions.utils.FormsUtils;

@AquimaService("BB_GetValueFromArray")
public class GetValueFromArrayService implements IService {
	
	private final static Logger LOG = LoggerFactory.getLogger(GetValueFromArrayService.class);

    @Override
    public IServiceResult handle(IServiceContext serviceContext) {
        LOG.debug("GetValueFromArrayService: called");

        // Input parameters of service
        IValue arrayOfValues = FormsUtils.getExpressionAttrByParameter(serviceContext, "multi-value");        
        IValue position = FormsUtils.getExpressionAttrByParameter(serviceContext, "position");
        // Output value of service
        String formsAttributeName = serviceContext.getParameter("result");

        // If all set correctly
        if (arrayOfValues != null && position != null && position.integerValue() >= 0 && position.integerValue() < arrayOfValues.toListValue().getValueCount()) {
        	// Create list and get the value at requested position
	        IPrimitiveValue valueAtRequestedPosition = arrayOfValues.toListValue().getValueAt(position.integerValue());
	        LOG.debug("Value at position " + position.integerValue() + ": ", valueAtRequestedPosition);
	        
	        // Set value in result parameter of service 	        
	        FormsUtils.setAttr(serviceContext, formsAttributeName, valueAtRequestedPosition, false, true);
        } else {
        	// Set value in result parameter of service to empty String (cannot be set to null because of implementation of FormsUtils.setAttr)
        	LOG.debug("Invalid position in array, set to empty String");
	        FormsUtils.setAttr(serviceContext, formsAttributeName, "", false, true);
        }

        LOG.debug("GetValueFromArrayService: finished");

        // Close service
        return new ServiceResult();
    }
}
