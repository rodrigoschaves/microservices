package com.backbase.expert.forms.extensions.services;

import com.aquima.interactions.foundation.IValue;
import com.aquima.interactions.framework.service.ServiceResult;
import com.aquima.interactions.portal.IService;
import com.aquima.interactions.portal.IServiceContext;
import com.aquima.interactions.portal.IServiceResult;
import com.aquima.interactions.portal.ServiceException;
import com.aquima.web.config.annotation.AquimaService;
import com.backbase.expert.forms.extensions.utils.FormsUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;


@AquimaService("BB_ClientIP")
public class ClientIpService implements IService {
    private final static Logger LOG = LoggerFactory.getLogger(GetPropertyService.class);

    @Override
    public IServiceResult handle(IServiceContext serviceContext)
            throws ServiceException, Exception {

        LOG.debug("ClientIpService: called");
        String remoteAddress = ((ServletRequestAttributes) RequestContextHolder
                .currentRequestAttributes()).getRequest().getRemoteAddr();

        IValue value = FormsUtils.getExpressionAttrByParameter(serviceContext, "AttributeName");
        // The 'AttributeName' value gets populated in the Forms Model.
        String formsAttributeName = value.isUnknown()?"":value.stringValue();
        LOG.debug("Attribute name: {}", formsAttributeName);

        FormsUtils.setAttr(serviceContext, formsAttributeName, remoteAddress, false, true);
        LOG.debug("Client IP: {}", remoteAddress);

        LOG.debug("ClientIpService: finished");

        return new ServiceResult();
    }

}