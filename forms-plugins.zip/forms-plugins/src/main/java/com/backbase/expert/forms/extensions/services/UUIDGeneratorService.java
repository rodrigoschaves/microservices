package com.backbase.expert.forms.extensions.services;

import com.aquima.interactions.framework.service.ServiceResult;
import com.aquima.interactions.portal.IService;
import com.aquima.interactions.portal.IServiceContext;
import com.aquima.interactions.portal.IServiceResult;
import com.aquima.web.config.annotation.AquimaService;
import com.backbase.expert.forms.extensions.utils.FormsUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.UUID;

@AquimaService("BB_GenerateID")
public class UUIDGeneratorService implements IService {

    private final static Logger LOG = LoggerFactory.getLogger(LogService.class);

    @Override
    public IServiceResult handle(IServiceContext serviceContext) {
        LOG.debug("UUIDGeneratorService: called");
        String idParameter = serviceContext.getParameter("ID");
        UUID uuid = UUID.randomUUID();
        FormsUtils.setAttr(serviceContext, idParameter, uuid.toString(), true, true);
        LOG.debug("UUIDGeneratorService: called");
        return new ServiceResult();
    }
}
