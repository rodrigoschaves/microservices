package com.backbase.expert.forms.extensions.services;

import com.aquima.interactions.foundation.IValue;
import com.aquima.interactions.framework.service.ServiceResult;
import com.aquima.interactions.portal.IService;
import com.aquima.interactions.portal.IServiceContext;
import com.aquima.interactions.portal.IServiceResult;
import com.aquima.web.config.annotation.AquimaService;
import com.backbase.expert.forms.extensions.utils.FormsUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by erwin on 22/08/15.
 * BB_TextExtract, where the text is using the XSLT Substring Before and Substring After to get to the value.
 * Leaving one of the two values empty should take all letters of that
 *
 * Input
 * SourceString: MonkeyTail [Mandatory in Forms Service]
 * StringAfter: Mon
 * StringBefore: Tail
 *
 * Output
 * Result : key [Mandatory in Forms Service]
 *
 */
@AquimaService("BB_TextExtract")

public class TextExtractService implements IService {

    private final static Logger LOG = LoggerFactory.getLogger(TextExtractService.class);

    @Override
    public IServiceResult handle(IServiceContext serviceContext) {

        LOG.debug("TextExtractService: called");

        // Input
        IValue sourceString = FormsUtils.getExpressionAttrByParameter(serviceContext, "SourceString");
        String stringAfter = serviceContext.getParameter("StringAfter");
        String stringBefore = serviceContext.getParameter("StringBefore");

        // Output
        String entityAttr = serviceContext.getParameter("Result");

        if (stringAfter == null) {
            stringAfter = "";
        }


        if (entityAttr != null && !entityAttr.isEmpty()) {
            String input = "";

            assert sourceString != null;

            if (!sourceString.isUnknown()) {
                input = sourceString.stringValue();
            }

            String after = StringUtils.substringAfter(input, stringAfter);
            String result = StringUtils.substringBefore(after, stringBefore);

            FormsUtils.setAttr(serviceContext, entityAttr, result, true, true);
        }
        LOG.debug("TextExtractService: called");

        return new ServiceResult();
    }
}