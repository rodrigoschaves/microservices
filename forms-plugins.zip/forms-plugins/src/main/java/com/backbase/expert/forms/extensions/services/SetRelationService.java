package com.backbase.expert.forms.extensions.services;

import com.aquima.interactions.foundation.IValue;
import com.aquima.interactions.portal.IService;
import com.aquima.interactions.portal.IServiceContext;
import com.aquima.interactions.portal.IServiceResult;
import com.aquima.interactions.profile.IEntityInstance;
import com.aquima.web.config.annotation.AquimaService;
import com.backbase.expert.forms.extensions.utils.FormsUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@AquimaService("BB_SetRelation")
public class SetRelationService implements IService {

    private static final Logger LOG = LoggerFactory.getLogger(SetRelationService.class);

    @Override
    public IServiceResult handle ( IServiceContext serviceContext ) {

        LOG.debug ( serviceContext.getServiceTypeName() + ":handle:begin" );
        String relationPathParameter = serviceContext.getParameter("relation-path");

        LOG.debug ( serviceContext.getServiceTypeName() + ":handle:relation-path:" + relationPathParameter );

        // extracting the relation entity from the relation path;
        String relationEntity = relationPathParameter.substring ( 0, relationPathParameter.lastIndexOf ( '.' ) );
        String relationScope = relationPathParameter.substring ( relationEntity.length() + 1 );

        LOG.debug ( serviceContext.getServiceTypeName() + ":handle:relationEntity:" + relationEntity );
        LOG.debug ( serviceContext.getServiceTypeName() + ":handle:relationScope:" + relationScope );

        // retrieving the relation entity instance;
        IEntityInstance relationEntityInstance = FormsUtils.extractEntityInstance(serviceContext, relationEntity);

        // retrieving the parameter with the instances that are going to be related with the entity;
        IValue instances = FormsUtils.getExpressionAttrByParameter(serviceContext, "instances");

        LOG.debug ( serviceContext.getServiceTypeName() + ":handle:relationEntityInstance:" + relationEntityInstance.toString() );
        LOG.debug ( serviceContext.getServiceTypeName() + ":handle:instances:" + instances.toString() );

        boolean addToRelation = "true".equalsIgnoreCase(serviceContext.getParameter ( "add-to-relation" ));

        LOG.debug ( serviceContext.getServiceTypeName() + ":handle:add-to-relation:" + addToRelation);

        // this flag determines whether the relation list is receiving the new instance
        // or if the whole relation list is being replaced by the instances provided;
        if ( addToRelation )
            // add value to existing list;
            relationEntityInstance.addValue(relationScope, instances.toSingleValue());
        else
            // replace the list;
            relationEntityInstance.setValue(relationScope, instances);

        LOG.debug ( serviceContext.getServiceTypeName() + ":handle:end" );

        // returns null when it has been successful;
        return null;

    }
}
