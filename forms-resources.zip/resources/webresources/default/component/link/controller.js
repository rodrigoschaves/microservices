(function () {
    /**
     * @ngInject
     */
    function LinkController($scope) {
    }
    angular.module('forms-ui').controller('LinkController', ['$scope', LinkController]);
})();
