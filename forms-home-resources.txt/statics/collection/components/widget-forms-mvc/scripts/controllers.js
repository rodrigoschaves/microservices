/**
 * Controllers
 * @module controllers
 */
(function () {

    'use strict';

    /**
     * Main controller
     * @ngInject
     * @constructor
     */
    angular.module('widget-forms-mvc')
        .controller('MainCtrl', function (widget, $scope, $filter, shortcutService) {

            $scope.isDesignMode = !!bd.designMode;

            $scope.runtimeUrl = b$.portal.config.serverRoot + '/services/forms';

            // Get avaialble shortcurts
            shortcutService.getShortcuts()
                .then(function (response) {
                    $scope.shortcuts = response.data.items.length && response.data.items || [];
                    updateConfiguration();
                }, function () {
                    $scope.shortcuts = [];
                });

            if ($scope.isDesignMode) {


                // Add available shortcuts to the preferences
                widget.addEventListener("preferences-form", function (evt) {
                    var prefs = evt.detail.customPrefsModel = b$.portal.portalModel.filterPreferences(widget.model.preferences.array);
                    var shortcurtsPreference = $filter('filter')(prefs, {name: "shortcut"}, true)[0];

                    shortcurtsPreference.inputType.options = [];

                    if (!$scope.shortcuts.length) {
                        shortcurtsPreference.inputType.options.push({
                            label: 'No shortcut available',
                            value: ''
                        });
                    } else {
                        angular.forEach($scope.shortcuts, function (value) {
                            shortcurtsPreference.inputType.options.push({
                                label: value.name,
                                value: value.name
                            });
                        });
                    }
                });

                widget.model.addEventListener('PrefModified', function (ev) {
                    updateConfiguration();

                    $scope.$apply();
                });
            }

            function updateConfiguration() {
                //warn about missing config
                var requiredPreferenceKeys = ['project', 'flow', 'branch', 'lang'];

                var shortcut = widget.getPreference('shortcut');

                if (!shortcut) {
                    $scope.missingPreference = 'shortcut';
                    return;
                }

                delete $scope.missingPreference;

                $scope['shortcut'] = $scope.shortcuts.filter(function (s) {
                    return s.name === shortcut;
                })[0];

                $scope.config = {
                    runtimePath: b$.portal.config.serverRoot + '/services/forms',
                    project: $scope['shortcut'].project,
                    flow: $scope['shortcut'].flow,
                    theme: $scope['shortcut'].theme,
                    lang: $scope['shortcut'].languageCode,
                    branch: $scope['shortcut'].version
                };

                $scope.$broadcast('configUpdated', $scope.config);

            }

            $scope.parameters = {
                noTools: true
            };

        });
})();