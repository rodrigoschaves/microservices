# module-example

Launchpad Module Example


| name                  | version           | bundle           |
| ----------------------|:-----------------:| ----------------:|
| module-example        | 0.0.1 |                  |
