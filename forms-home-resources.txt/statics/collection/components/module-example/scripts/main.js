/**
 *  ----------------------------------------------------------------
 *  Copyright © Backbase B.V.
 *  ----------------------------------------------------------------
 *  Filename : main.js
 *  Description: Main entry point
 *  ----------------------------------------------------------------
 */

define( function (require, exports, module) {

    'use strict';

   module.exports = {};

});
