package com.backbase.expert.forms.examples.plugin;

import com.aquima.interactions.portal.IService;
import com.aquima.interactions.portal.IServiceContext;
import com.aquima.interactions.portal.IServiceResult;
import com.aquima.interactions.portal.ServiceException;
import com.aquima.web.config.annotation.AquimaService;

@AquimaService("MyCustomService")
public class CustomService implements IService{

	@Override
	public IServiceResult handle(IServiceContext context) throws ServiceException,
			Exception {
		
		return null;
	}

}
