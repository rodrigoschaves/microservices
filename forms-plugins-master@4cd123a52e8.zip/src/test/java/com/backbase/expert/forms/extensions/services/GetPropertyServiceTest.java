package com.backbase.expert.forms.extensions.services;

import com.aquima.interactions.portal.IService;
import com.aquima.interactions.portal.IServiceContext;
import com.aquima.interactions.rule.InferenceContext;
import com.backbase.expert.forms.context.AquimaContextLoader;
import com.backbase.expert.forms.extensions.utils.FormsUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.*;

/**
 * Test class for GetPropertyService.
 *
 * @author Dirk Gietelink [dirk]
 * @since 2015-10-06
 */
@RunWith(SpringJUnit4ClassRunner.class)
public class GetPropertyServiceTest extends AquimaContextLoader {
    
    private static final String projectZipPath = "/exports/Plugins.project.zip";
    private static final String profileXmlPath = "/exports/Start_Plugins.all-loaded.profile.xml";
    
    @Autowired
    @Qualifier("BB_GetProperty")
    private IService service;
    private IServiceContext context;

    @Before
    public void setup() throws Exception {
        String serviceCallName = "WhateverServiceName";
        String serviceTypeName = "BB_GetProperty";
        Map<String, String> expressionParameters = createExpressionParameterMap();
        Map<String, String> valueParameters = createValueParameterMap();
        context = loadFullContext(projectZipPath, profileXmlPath, serviceCallName, serviceTypeName,
                valueParameters, expressionParameters);
    }

    private Map<String,String> createValueParameterMap() {
        Map<String, String> params = new HashMap<String, String>();
        // aquima.properties:  connection.PayU.http.url=https://secure.payu.com/
        params.put("PropertyName", "connection.PayU.http.url");
        return params;
    }
    private Map<String,String> createExpressionParameterMap() {
        Map<String, String> params = new HashMap<String, String>();
        params.put("AttributeName", "Plugins.TextExtractResult");
        return params;
    }

    @Test
    public void testGetPropertyHappyPath() throws Exception {
        InferenceContext profile = context.getProfile();
        assertNotNull(profile);
        String attrBefore = FormsUtils.getAttr(context, "Plugins", "TextExtractResult");
        assertNull(attrBefore);
        service.handle(context);
        String attrAfter = FormsUtils.getAttr(context, "Plugins", "TextExtractResult");
        assertNotNull(attrAfter);
        System.out.println(attrAfter);
        assertEquals(attrAfter, "https://secure.payu.com/");
    }

}
