package com.backbase.expert.forms.examples.plugin;

import com.aquima.interactions.composer.model.Button;
import com.aquima.interactions.composer.model.Container;
import com.aquima.interactions.composer.model.definition.ContainerDefinition;
import com.aquima.interactions.foundation.text.MultilingualText;
import com.aquima.interactions.portal.IContainerContext;
import com.aquima.interactions.portal.IContainerExpander;
import com.aquima.web.config.annotation.AquimaExpander;

@AquimaExpander("MyDynamicContainer")
public class DynamicContainer implements IContainerExpander {

	@Override
	public Container expand(Container container, ContainerDefinition definition,
			IContainerContext context) throws Exception {

		String nameOfPerson = context.getProfile().getActiveInstance("Person").getValue("Name").stringValue();
		
		container.addElement(new Button("mybutton", new MultilingualText(nameOfPerson)));
		return container;
	}

}
