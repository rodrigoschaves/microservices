package com.backbase.expert.forms.extensions.services;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.spi.LoggingEvent;
import ch.qos.logback.core.Appender;
import com.aquima.interactions.portal.IService;
import com.aquima.interactions.portal.IServiceContext;
import com.aquima.interactions.rule.InferenceContext;
import com.backbase.expert.forms.context.AquimaContextLoader;
import com.backbase.expert.forms.extensions.utils.FormsUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.is;

/**
 * Test class for LogService.
 *
 * @author Dirk Gietelink [dirk]
 * @since 2015-10-06
 */
@RunWith(MockitoJUnitRunner.class)
public class LogServiceTest extends AquimaContextLoader {

    private static final String projectZipPath = "/exports/Plugins.project.zip";
    private static final String profileXmlPath = "/exports/Start_Plugins.log-message.profile.xml";

    private IService service;
    private IServiceContext context;

    @Mock
    private Appender mockAppender;
    //Captor is genericised with ch.qos.logback.classic.spi.LoggingEvent
    @Captor
    private ArgumentCaptor<LoggingEvent> captorLoggingEvent;

    @Before
    public void setup() throws Exception {
        String serviceCallName = "WhateverServiceName";
        String serviceTypeName = "BB_Log";
        Map<String, String> expressionParameters = createExpressionParameterMap();
        Map<String, String> valueParameters = createValueParameterMap();

        context = loadFullContext(projectZipPath, profileXmlPath, serviceCallName, serviceTypeName,
                valueParameters, expressionParameters);
        service = new LogService();
    }

    @After
    public void teardown() {
        // Detach the mock logger
        final Logger logger = (Logger) LoggerFactory.getLogger(Logger.ROOT_LOGGER_NAME);
        logger.detachAppender(mockAppender);
    }

    /**
     * Method to setup the Mock logger.
     */
    private void setupMockLogger() {
        final Logger logger = (Logger) LoggerFactory.getLogger(Logger.ROOT_LOGGER_NAME);
        logger.addAppender(mockAppender);
    }

    private Map<String,String> createExpressionParameterMap() {
        Map<String, String> params = new HashMap<String, String>();
        params.put("Message", "Plugins.LogMessage");  // Plugins.LogMessage = something
        return params;
    }

    private Map<String,String> createValueParameterMap() {
        Map<String, String> params = new HashMap<String, String>();
        params.put("Level", "INFO");
        return params;
    }

    @Test
    public void testLogMessageHappyPath() throws Exception {
        InferenceContext profile = context.getProfile();
        assertNotNull(profile);
        String logMessageBefore = FormsUtils.getAttr(context, "Plugins", "LogMessage");
        assertEquals("something", logMessageBefore);
        String logSeverity = FormsUtils.getAttr(context, "Plugins", "LogSeverity");
        assertEquals("info", logSeverity);
        
        setupMockLogger();
        service.handle(context);
        String logMessageAfter = FormsUtils.getAttr(context, "Plugins", "LogMessage");
        assertEquals("something", logMessageAfter);

        //Now verify our logging interactions
        Mockito.verify(mockAppender).doAppend(captorLoggingEvent.capture());
        //Having a genricised captor means we don't need to cast
        final LoggingEvent loggingEvent = captorLoggingEvent.getValue();
        //Check log level is correct
        assertThat(loggingEvent.getLevel(), is(Level.INFO));
        //Check the message being logged is correct
        assertThat(loggingEvent.getFormattedMessage(), is("something"));
    }

}
