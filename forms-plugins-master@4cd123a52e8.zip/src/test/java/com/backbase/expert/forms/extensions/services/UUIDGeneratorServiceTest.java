package com.backbase.expert.forms.extensions.services;

import com.aquima.interactions.portal.IService;
import com.aquima.interactions.portal.IServiceContext;
import com.aquima.interactions.rule.InferenceContext;
import com.backbase.expert.forms.context.AquimaContextLoader;
import com.backbase.expert.forms.extensions.utils.FormsUtils;
import org.junit.Before;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import static org.junit.Assert.*;

/**
 * Test class for UUIDGeneratorService.
 *
 * @author Dirk Gietelink [dirk]
 * @since 2015-10-06
 */
public class UUIDGeneratorServiceTest extends AquimaContextLoader {

    private static final String projectZipPath = "/exports/Plugins.project.zip";
    private static final String profileXmlPath = "/exports/Start_Plugins.all-loaded.profile.xml";

    private IService service;
    private IServiceContext context;

    @Before
    public void setup() throws Exception {
        String serviceCallName = "WhateverServiceName";
        String serviceTypeName = "BB_GenerateID";
        Map<String, String> expressionParameters = createExpressionParameterMap();
        Map<String, String> valueParameters = null;

        context = loadFullContext(projectZipPath, profileXmlPath, serviceCallName, serviceTypeName,
                valueParameters, expressionParameters);
        service = new UUIDGeneratorService();
    }

    private Map<String,String> createExpressionParameterMap() {
        Map<String, String> params = new HashMap<String, String>();
        params.put("ID", "Plugins.UUID");
        return params;
    }

    @Test
    public void testGenerateUUIDHappyPath() throws Exception {
        InferenceContext profile = context.getProfile();
        assertNotNull(profile);
        String attrBefore = FormsUtils.getAttr(context, "Plugins", "UUID");
        assertNull(attrBefore);
        service.handle(context);
        String attrAfter = FormsUtils.getAttr(context, "Plugins", "UUID");
        assertNotNull(attrAfter);
        assertEquals(36, attrAfter.length());
        System.out.println(attrAfter);
        UUID uuidFormatted = UUID.fromString(attrAfter);
        System.out.println(uuidFormatted);
        assertEquals(attrAfter, uuidFormatted.toString());
    }

}
