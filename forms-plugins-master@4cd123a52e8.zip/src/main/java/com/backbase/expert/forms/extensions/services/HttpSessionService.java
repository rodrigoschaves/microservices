package com.backbase.expert.forms.extensions.services;

import com.aquima.interactions.framework.service.ServiceResult;
import com.aquima.interactions.portal.IService;
import com.aquima.interactions.portal.IServiceContext;
import com.aquima.interactions.portal.IServiceResult;
import com.aquima.web.config.annotation.AquimaService;
import com.backbase.expert.forms.extensions.utils.FormsUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Stores or retrieves an attribute value in or from the HttpSession.
 * <br>
 * <ul>
 *     <li>target-attribute-path ==> entity.attribute reference</li>
 *     <li>from-or-to ==> the string 'from' or 'to'.
 *     'from' will retrieve attribute from the http session and store it in the profile.<br/>
 *     'to' vice versa. Please note that attribute names in the session scope are converted to lowercase.</li>
 * </ul>
 *
 * @author Dirk Gietelink [dirk]
 * @since 2015-12-24
 */
@AquimaService("BB_HttpSession")
public class HttpSessionService implements IService {

    private static final Logger LOG = LoggerFactory.getLogger(HttpSessionService.class);

    @Override
    public IServiceResult handle(IServiceContext serviceContext) {
        LOG.debug("HttpSessionService: called");

        String targetAttributeName = serviceContext.getParameter("target-attribute-path");
        String fromOrTo = serviceContext.getParameter("from-or-to");

        if(fromOrTo != null && targetAttributeName != null) {
            if("from".equalsIgnoreCase(fromOrTo)) {
                String targetLowerCase = targetAttributeName.toLowerCase();
                String attrValue = (String) serviceContext.getUserScope().getAttribute(targetLowerCase);
                FormsUtils.setAttr(serviceContext, targetAttributeName, attrValue, true, true);
                LOG.info("HTTP session attribute {} is retrieved and persisted in the Forms profile using the name as reference.");
            }
            else if("to".equalsIgnoreCase(fromOrTo)) {
                String entityName = StringUtils.substringBeforeLast(targetAttributeName, ".");
                String attrName = StringUtils.substringAfterLast(targetAttributeName, ".");
                String attrValue = FormsUtils.getAttr(serviceContext, entityName, attrName);
                serviceContext.getUserScope().setAttribute(targetAttributeName, attrValue);
                LOG.info("Value of {} is stored in HTTP session in an attribute with the same name.");
            }
            else {
                 LOG.error("Parameter from-or-to should be either 'from' or 'to' without quotes. Found: {}", fromOrTo);
            }

        }
        LOG.debug("HttpSessionService: finished");

        return new ServiceResult();
    }
}
