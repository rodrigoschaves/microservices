package com.backbase.expert.forms.extensions.services;

import com.aquima.interactions.foundation.IValue;
import com.aquima.interactions.framework.service.ServiceResult;
import com.aquima.interactions.portal.IService;
import com.aquima.interactions.portal.IServiceContext;
import com.aquima.interactions.portal.IServiceResult;
import com.aquima.web.config.annotation.AquimaService;
import com.backbase.expert.forms.extensions.utils.FormsUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@AquimaService("BB_TextReplace")
public class TextReplaceService implements IService {

    private final static Logger LOG = LoggerFactory.getLogger(LogService.class);

    @Override
    public IServiceResult handle(IServiceContext serviceContext) {

        LOG.debug("TextReplaceService: called");

        IValue inputValue = FormsUtils.getExpressionAttrByParameter(serviceContext, "SourceString");
        String regex = serviceContext.getParameter("StringToFind");
        if (regex == null)
            regex = "";
        String template = serviceContext.getParameter("StringToReplace");
        if (template == null)
            template = "";
        String entityAttr = serviceContext.getParameter("Result");

        if (entityAttr != null && !entityAttr.isEmpty()) {
            String input = "";
            if (!inputValue.isUnknown())
                input = inputValue.stringValue();

            String result = input.replaceAll(regex, template);

            FormsUtils.setAttr(serviceContext, entityAttr, result, true, true);
        }
        LOG.debug("TextReplaceService: finished");

        return new ServiceResult();
    }
}
