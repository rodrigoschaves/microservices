package com.backbase.expert.forms.extensions.services;

import org.apache.commons.lang.StringUtils;

import com.aquima.interactions.foundation.DataType;
import com.aquima.interactions.foundation.IValue;
import com.aquima.interactions.portal.IService;
import com.aquima.interactions.portal.IServiceContext;
import com.aquima.interactions.portal.IServiceResult;
import com.aquima.interactions.portal.ServiceException;
import com.aquima.interactions.profile.IEntityInstance;
import com.aquima.web.config.annotation.AquimaService;
import com.backbase.expert.forms.extensions.utils.FormsUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *  When we separate split-string into array, each value of array should be added as the attribute(target-attribute) value of each instance(target-instance).
 *  Each new instance is added as part of relation parent instance
 *
 * Parameters:
 * split-flag  use as separator to split string (expected String)
 * split-string represents text which will be separated (expected String)
 * relation we use it as expression to get parent instance
 * target-instance represents Class of new instances that we created (expected String)
 * target-attribute is name of attribute where we will set new values that are coming from split-string
 * 
 * returns null if everything is ok, all new values, attributes, instances should be added as part of context
 * 
 *
 *   @author Sanja Vasic
 *   @since 2015-09-23
 */
@AquimaService("BB_SplitAttributeToInstance")
public class SplitAttributeToInstance implements IService {

	private final static Logger LOG = LoggerFactory.getLogger(SplitAttributeToInstance.class);

	@Override
	public IServiceResult handle(IServiceContext ctx) throws ServiceException, Exception {
		LOG.debug("SplitAttributeToInstance: called");

		// Input
		IValue splitParam = FormsUtils.getExpressionAttrByParameter(ctx, "split-flag");
		IValue sourceParam = FormsUtils.getExpressionAttrByParameter(ctx, "split-string");

		if (splitParam!=null && DataType.STRING.equals(splitParam.getDataType()) && sourceParam!=null && DataType.STRING.equals(sourceParam.getDataType())) {

			String splitFlag=splitParam.stringValue();
			String sourceString=sourceParam.stringValue();
			
			// Output
			String expressionParam = ctx.getParameter("relation");
			String entityName = ctx.getParameter("target-instance");
			String attributeName = ctx.getParameter("target-attribute");

			if (StringUtils.isNotBlank(splitFlag) && StringUtils.isNotBlank(sourceString)) {
				// extracting the  entity from the relation path;
				String parentEntity = expressionParam.substring(0, expressionParam.lastIndexOf('.'));
				String relationScope = expressionParam.substring(parentEntity.length() + 1);

				IEntityInstance entityInstance = FormsUtils.extractEntityInstance(ctx, parentEntity);
		
				String[] attributes = StringUtils.split(sourceString, splitFlag);
		
				for (String newAttribute : attributes) {
					IEntityInstance newInstance = ctx.getProfile().createInstance(entityName);
					newInstance.setValue(attributeName, newAttribute);
					entityInstance.addValue(relationScope, newInstance.getInstanceReference());
				}		
			}
		}
		LOG.debug("SplitAttributeToInstance: finished");

		return null;
	}

}
