package com.backbase.expert.forms.extensions.services;

import com.aquima.interactions.portal.IService;
import com.aquima.interactions.portal.IServiceContext;
import com.aquima.interactions.portal.IServiceResult;
import com.aquima.web.config.annotation.AquimaService;
import com.backbase.expert.forms.extensions.utils.FormsUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import java.util.Properties;

@AquimaService(value = "BB_GetProperty")
public class GetPropertyService implements IService {

    private final static Logger LOG = LoggerFactory.getLogger(GetPropertyService.class);

    @Autowired
    @Qualifier("backbaseProperties")
    private Properties backbaseProperties;

    @Autowired
    @Qualifier("aquimaProperties")
    private Properties aquimaProperties;

    @Override
    public IServiceResult handle(IServiceContext serviceContext) throws Exception {
        String propertyName = serviceContext.getParameter("PropertyName");
        
        LOG.debug("Property name: {}", propertyName);
        LOG.debug("Property name: {}", propertyName);

        String propertyValue = backbaseProperties.getProperty(propertyName);
        LOG.debug("Property value: {}", propertyValue);

        if(propertyValue == null || propertyValue.length() == 0) {
            propertyValue = aquimaProperties.getProperty(propertyName);
            LOG.debug("Property value: {}", propertyValue);
        }

        // The 'AttributeName' is the name of the attribute where the value gets populated in the Forms Model.
        String formsAttributeName = serviceContext.getParameter("AttributeName");
        LOG.debug("Attribute name: {}", formsAttributeName);
        FormsUtils.setAttr(serviceContext, formsAttributeName, propertyValue, false, true);

        return null;
    }
}
