package com.backbase.expert.forms.extensions.services;

import com.aquima.interactions.foundation.IValue;
import com.aquima.interactions.framework.service.ServiceResult;
import com.aquima.interactions.portal.IService;
import com.aquima.interactions.portal.IServiceContext;
import com.aquima.interactions.portal.IServiceResult;
import com.aquima.web.config.annotation.AquimaService;
import com.backbase.expert.forms.extensions.utils.FormsUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@AquimaService("BB_SetAttribute")
public class SetAttributeService implements IService {

    private final static Logger LOG = LoggerFactory.getLogger(SetAttributeService.class);

    @Override
    public IServiceResult handle(IServiceContext serviceContext) {
        LOG.debug("SetAttributeService: called");

        String targetAttributeName = serviceContext.getParameter("target-attribute-path");
        IValue value = FormsUtils.getExpressionAttrByParameter(serviceContext, "value");

        FormsUtils.setAttr(serviceContext, targetAttributeName, value, false, true);
        LOG.debug("SetAttributeService: finished");

        return new ServiceResult();
    }
}
