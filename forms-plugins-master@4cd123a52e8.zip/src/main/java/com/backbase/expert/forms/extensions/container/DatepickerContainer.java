package com.backbase.expert.forms.extensions.container;

import com.aquima.interactions.composer.model.Container;
import com.aquima.interactions.composer.model.RendererProperty;
import com.aquima.interactions.composer.model.definition.ContainerDefinition;
import com.aquima.interactions.portal.IContainerContext;
import com.aquima.interactions.portal.IContainerExpander;
import com.aquima.web.config.annotation.AquimaExpander;
import com.backbase.expert.forms.extensions.utils.FormsUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Custom container for a slider UI component.
 * The container consumes evaluates the expression parameters, logs the key/value pairs,
 * and set them as properties of the container, before returning.
 *
 * @author Dirk Gietelink [dirk]
 * @since 2015-10-28
 */
@AquimaExpander(value = "BB_Datepicker")
public class DatepickerContainer implements IContainerExpander {

    private static final Logger LOG = LoggerFactory.getLogger(DatepickerContainer.class);
    private static final String MIN_VALUE_KEY = "min-date";
    private static final String MAX_VALUE_KEY = "max-date";
    private static final String VIEW_MODE_KEY = "view-mode";

    @Override
    public Container expand(Container container, ContainerDefinition containerDefinition, IContainerContext containerContext) throws Exception {
        LOG.debug("Start Datepicker Container");

        container.addElements(containerContext.getElementComposer().expandChildren(containerDefinition));

        Date minValue = FormsUtils.evaluateContainerContextParameterExpressionToDate(containerContext, MIN_VALUE_KEY);
        Date maxValue = FormsUtils.evaluateContainerContextParameterExpressionToDate(containerContext, MAX_VALUE_KEY);
        String viewMode  = FormsUtils.evaluateContainerContextParameterExpressionToString(containerContext, VIEW_MODE_KEY);

        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        if(minValue != null)
            setContainerProperty(container, MIN_VALUE_KEY, df.format(minValue));

        if(maxValue != null)
            setContainerProperty(container, MAX_VALUE_KEY, df.format(maxValue));

        setContainerProperty(container, VIEW_MODE_KEY, viewMode);

        return container;
    }

    /**
     * Sets property to the container, and logs the value.
     * @param container
     * @param key
     * @param value
     */
    private void setContainerProperty(Container container, String key, String value) {
        container.setProperty(key, new RendererProperty(value));
        LOG.debug("Datepicker [{}] custom property set: {}={}", container.getName(), key, value);
    }

}
