package com.backbase.expert.forms.extensions.container;

import com.aquima.interactions.composer.model.Container;
import com.aquima.interactions.composer.model.RendererProperty;
import com.aquima.interactions.composer.model.definition.ContainerDefinition;
import com.aquima.interactions.portal.IContainerContext;
import com.aquima.interactions.portal.IContainerExpander;
import com.aquima.web.config.annotation.AquimaExpander;
import com.backbase.expert.forms.extensions.utils.FormsUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Custom container for a slider UI component.
 * The container consumes evaluates the expression parameters, logs the key/value pairs,
 * and set them as properties of the container, before returning.
 *
 * @author Dirk Gietelink [dirk]
 * @since 2015-10-28
 */
@AquimaExpander(value = "BB_Recaptcha")
public class RecaptchaContainer implements IContainerExpander {

    private static final Logger LOG = LoggerFactory.getLogger(RecaptchaContainer.class);

    private static final String SITE_KEY = "data-sitekey";

    @Value("#{backbaseProperties['recaptcha.sitekey']}")
    private String siteKeyValue;

    @Override
    public Container expand(Container container, ContainerDefinition containerDefinition, IContainerContext containerContext) throws Exception {
        LOG.debug("Start Datepicker Container");

        container.addElements(containerContext.getElementComposer().expandChildren(containerDefinition));

        setContainerProperty(container, SITE_KEY, siteKeyValue);

        return container;
    }

    /**
     * Sets property to the container, and logs the value.
     * @param container
     * @param key
     * @param value
     */
    private void setContainerProperty(Container container, String key, String value) {
        container.setProperty(key, new RendererProperty(value));
        LOG.debug("Datepicker [{}] custom property set: {}={}", container.getName(), key, value);
    }

}
