package com.backbase.expert.forms.extensions.container;

import com.aquima.interactions.composer.model.Container;
import com.aquima.interactions.composer.model.RendererProperty;
import com.aquima.interactions.composer.model.definition.ContainerDefinition;
import com.aquima.interactions.portal.IContainerContext;
import com.aquima.interactions.portal.IContainerExpander;
import com.aquima.web.config.annotation.AquimaExpander;
import com.backbase.expert.forms.extensions.utils.FormsUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Custom container for a slider UI component.
 * The container consumes evaluates the expression parameters, logs the key/value pairs,
 * and set them as properties of the container, before returning.
 *
 * @author Dirk Gietelink [dirk]
 * @since 2015-10-28
 */
@AquimaExpander(value = "BB_Slider")
public class SliderContainer implements IContainerExpander {

    private static final Logger LOG = LoggerFactory.getLogger(SliderContainer.class);
    private static final String MIN_VALUE_KEY = "min-value";
    private static final String MAX_VALUE_KEY = "max-value";
    private static final String STEPS_KEY = "steps";

    @Override
    public Container expand(Container container, ContainerDefinition containerDefinition, IContainerContext containerContext) throws Exception {
        LOG.debug("Start SliderContainer Container");

        container.addElements(containerContext.getElementComposer().expandChildren(containerDefinition));

        String minValue = FormsUtils.evaluateContainerContextParameterExpressionToString(containerContext, MIN_VALUE_KEY);
        String maxValue = FormsUtils.evaluateContainerContextParameterExpressionToString(containerContext, MAX_VALUE_KEY);
        String steps = FormsUtils.evaluateContainerContextParameterExpressionToString(containerContext, STEPS_KEY);

        setContainerProperty(container, MIN_VALUE_KEY, minValue);
        setContainerProperty(container, MAX_VALUE_KEY, maxValue);
        setContainerProperty(container, STEPS_KEY, steps);
        
        return container;
    }

    /**
     * Sets property to the container, and logs the value.
     * @param container
     * @param key
     * @param value
     */
    private void setContainerProperty(Container container, String key, String value) {
        container.setProperty(key, new RendererProperty(value));
        LOG.debug("SliderContainer [{}] custom property set: {}={}", container.getName(), key, value);
    }

}
